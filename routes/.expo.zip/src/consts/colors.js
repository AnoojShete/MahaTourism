const COLORS = {
  white: '#FFF',
  dark: '#000',
  primary: '#F75D37',
  secondary: '#F75D37',
  light: '#f9f9f9',
  grey: '#dddedd',
  red: 'red'
};

export default COLORS;
